import { z } from "zod";

export const NAME_MAX = 100;
export const EMAIL_MAX = 255;
export const SUBJECT_MAX = 150;
export const MESSAGE_MIN = 10;
export const MESSAGE_MAX = 2000;

const fields = {
  name: z
    .string()
    .trim()
    .min(2, { message: "Please enter your name (at least 2 characters)" })
    .max(NAME_MAX, { message: `Name must be under ${NAME_MAX} characters` })
    .regex(/^[\p{L}\p{M}\s.'-]+$/u, { message: "Name can only contain letters, spaces, dots, hyphens and apostrophes" }),
  email: z
    .string()
    .trim()
    .min(1, { message: "Please enter your email" })
    .email({ message: "Please enter a valid email address, like name@example.com" })
    .max(EMAIL_MAX, { message: `Email must be under ${EMAIL_MAX} characters` }),
  subject: z.string().trim().max(SUBJECT_MAX, { message: `Subject must be under ${SUBJECT_MAX} characters` }).optional(),
  message: z
    .string()
    .trim()
    .min(1, { message: "Please write a message" })
    .min(MESSAGE_MIN, { message: `Message should be at least ${MESSAGE_MIN} characters` })
    .max(MESSAGE_MAX, { message: `Message must be under ${MESSAGE_MAX} characters` }),
};

export const contactSchema = z.object(fields);

export type ContactInput = z.infer<typeof contactSchema>;

/** Validate one field; returns the first error message or undefined. */
export function validateContactField(field: keyof ContactInput, value: string): string | undefined {
  const result = fields[field].safeParse(value);
  return result.success ? undefined : result.error.issues[0]?.message;
}
