export const profile = {
  name: "Admal Francis Titto",
  firstName: "Admal",
  role: "BSc Computer Science Student",
  tagline:
    "I'm a Computer Science student who enjoys turning ideas into clean, useful software — from Python scripts to responsive websites.",
  college: "Sahrdaya College of Advanced Studies",
  course: "BSc Computer Science",
  years: "2026 – 2030",
  location: "Thrissur, Kerala",
  email: "admalfrancistitto08@gmail.com",
  phone: "+91 91888 91884",
  phoneHref: "tel:+919188891884",
  github: "https://github.com/admalfrancistitto",
  linkedin: "https://in.linkedin.com/in/admal-francis-titto-98147444b",
};

export const navLinks = [
  { id: "home", label: "Home" },
  { id: "about", label: "About" },
  { id: "skills", label: "Skills" },
  { id: "projects", label: "Projects" },
  { id: "contact", label: "Contact" },
] as const;

export type SectionId = (typeof navLinks)[number]["id"];

export const skills = [
  { name: "Python", level: 80, note: "Scripting, problem solving, data handling" },
  { name: "HTML", level: 90, note: "Semantic, accessible page structure" },
  { name: "CSS", level: 85, note: "Responsive layouts, Flexbox, Grid, animations" },
  { name: "JavaScript", level: 75, note: "DOM, events, fetch APIs, ES6+" },
];

export const tools = ["Git & GitHub", "VS Code", "Linux basics", "SQL", "Problem Solving", "Teamwork"];

export const projects: {
  title: string;
  description: string;
  icon: "chart" | "cloud" | "board";
  tags: string[];
}[] = [
  {
    title: "Student Data Dashboard",
    description:
      "A Python tool that reads marks from CSV files, calculates averages and grades, and shows the results as clear charts.",
    icon: "chart",
    tags: ["Python", "Pandas", "Matplotlib"],
  },
  {
    title: "Weather Now",
    description:
      "A responsive weather app that shows live temperature, humidity and a 5-day forecast for any city using a public weather API.",
    icon: "cloud",
    tags: ["HTML", "CSS", "JavaScript", "API"],
  },
  {
    title: "TaskFlow Board",
    description:
      "A drag-and-drop task board to plan study work. Tasks are saved in the browser so nothing is lost after a refresh.",
    icon: "board",
    tags: ["JavaScript", "CSS", "LocalStorage"],
  },
];
