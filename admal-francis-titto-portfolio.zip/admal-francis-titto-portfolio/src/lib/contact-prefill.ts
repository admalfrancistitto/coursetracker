// Lets any button (e.g. a project's "Ask about it") pre-fill the contact form subject.
export const CONTACT_PREFILL_EVENT = "portfolio:contact-prefill";

export function prefillContact(subject: string) {
  window.dispatchEvent(new CustomEvent<string>(CONTACT_PREFILL_EVENT, { detail: subject }));
  document.getElementById("contact")?.scrollIntoView({ behavior: "smooth", block: "start" });
}
