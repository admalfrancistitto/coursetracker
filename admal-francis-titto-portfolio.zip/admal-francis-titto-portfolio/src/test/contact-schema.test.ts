import { describe, expect, it } from "vitest";
import { contactSchema, validateContactField } from "@/lib/contact-schema";

const valid = { name: "Jane", email: "jane@example.com", subject: "", message: "Hello there, nice portfolio!" };

describe("contact form rules", () => {
  it("accepts a complete message", () => {
    expect(contactSchema.safeParse(valid).success).toBe(true);
  });
  it("rejects an invalid email", () => {
    expect(contactSchema.safeParse({ ...valid, email: "not-an-email" }).success).toBe(false);
  });
  it("rejects an empty name", () => {
    expect(contactSchema.safeParse({ ...valid, name: "   " }).success).toBe(false);
  });
  it("rejects a name with numbers or symbols", () => {
    expect(validateContactField("name", "J4ne<script>")).toBeDefined();
  });
  it("accepts names with accents, dots and apostrophes", () => {
    expect(validateContactField("name", "Seán O'Neil Jr.")).toBeUndefined();
  });
  it("rejects a message shorter than 10 characters", () => {
    expect(contactSchema.safeParse({ ...valid, message: "Hi" }).success).toBe(false);
  });
  it("rejects a message over 2000 characters", () => {
    expect(contactSchema.safeParse({ ...valid, message: "a".repeat(2001) }).success).toBe(false);
  });
  it("lets the subject be left blank", () => {
    expect(validateContactField("subject", "")).toBeUndefined();
  });
});
