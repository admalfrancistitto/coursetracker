import { useEffect, useRef, useState, type FormEvent, type ReactNode } from "react";
import { AlertCircle, CheckCircle2, Loader2, Mail, MapPin, Phone, Send } from "lucide-react";
import { toast } from "sonner";
import { Reveal, SectionHeading } from "./Reveal";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { supabase } from "@/integrations/supabase/client";
import { contactSchema, validateContactField, MESSAGE_MAX, type ContactInput } from "@/lib/contact-schema";
import { CONTACT_PREFILL_EVENT } from "@/lib/contact-prefill";
import { profile } from "@/lib/portfolio-data";
import { cn } from "@/lib/utils";

type FieldName = keyof ContactInput;
type Errors = Partial<Record<FieldName, string | undefined>>;
const FIELDS: FieldName[] = ["name", "email", "subject", "message"];
const empty: Record<FieldName, string> = { name: "", email: "", subject: "", message: "" };

const fieldClass =
  "bg-background/60 transition-colors focus-visible:ring-2 focus-visible:ring-primary/60 aria-[invalid=true]:border-destructive aria-[invalid=true]:focus-visible:ring-destructive/50";

export function Contact() {
  const [values, setValues] = useState(empty);
  const [errors, setErrors] = useState<Errors>({});
  const [touched, setTouched] = useState<Partial<Record<FieldName, boolean>>>({});
  const [status, setStatus] = useState<"idle" | "sending" | "sent">("idle");
  const [sentName, setSentName] = useState("");
  const [honeypot, setHoneypot] = useState("");
  const [formError, setFormError] = useState("");
  const nameRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    const onPrefill = (e: Event) => {
      const subject = (e as CustomEvent<string>).detail;
      setStatus("idle");
      setValues((v) => ({ ...v, subject }));
      setErrors((er) => ({ ...er, subject: undefined }));
      window.setTimeout(() => nameRef.current?.focus({ preventScroll: true }), 600);
    };
    window.addEventListener(CONTACT_PREFILL_EVENT, onPrefill);
    return () => window.removeEventListener(CONTACT_PREFILL_EVENT, onPrefill);
  }, []);

  const onChange = (key: FieldName) => (e: { target: { value: string } }) => {
    const value = e.target.value;
    setValues((v) => ({ ...v, [key]: value }));
    setFormError("");
    if (touched[key] || errors[key]) {
      setErrors((er) => ({ ...er, [key]: validateContactField(key, value) }));
    }
  };

  const onBlur = (key: FieldName) => () => {
    setTouched((t) => ({ ...t, [key]: true }));
    // Don't nag about an empty field the visitor just tabbed past.
    if (values[key].trim() === "" && !errors[key]) return;
    setErrors((er) => ({ ...er, [key]: validateContactField(key, values[key]) }));
  };

  async function onSubmit(e: FormEvent) {
    e.preventDefault();
    if (status === "sending") return;
    setFormError("");

    const parsed = contactSchema.safeParse(values);
    if (!parsed.success) {
      const fieldErrors: Errors = {};
      parsed.error.issues.forEach((i) => {
        const k = i.path[0] as FieldName;
        if (!fieldErrors[k]) fieldErrors[k] = i.message;
      });
      setErrors(fieldErrors);
      setTouched({ name: true, email: true, subject: true, message: true });
      const first = FIELDS.find((f) => fieldErrors[f]);
      if (first) document.getElementById(first)?.focus();
      return;
    }

    setStatus("sending");
    // Bots fill hidden fields; show success without saving.
    if (honeypot) {
      setSentName(parsed.data.name);
      setStatus("sent");
      return;
    }

    const { error } = await supabase.from("contact_submissions").insert({
      name: parsed.data.name,
      email: parsed.data.email,
      subject: parsed.data.subject || null,
      message: parsed.data.message,
    });

    if (error) {
      setStatus("idle");
      setFormError("Your message couldn't be sent. Please check your connection and try again.");
      toast.error("Message not sent. Please try again.");
      return;
    }

    setSentName(parsed.data.name.split(" ")[0] ?? parsed.data.name);
    setStatus("sent");
    setValues(empty);
    setErrors({});
    setTouched({});
    toast.success("Message sent successfully!");
  }

  const contactItems = [
    { Icon: Mail, label: "Email", value: profile.email, href: `mailto:${profile.email}` },
    { Icon: Phone, label: "Phone", value: profile.phone, href: profile.phoneHref },
    { Icon: MapPin, label: "Location", value: profile.location },
  ];

  return (
    <section id="contact" className="relative overflow-hidden bg-navy-deep py-20 sm:py-24 md:py-32">
      <div aria-hidden className="absolute -left-32 bottom-0 h-96 w-96 rounded-full bg-primary/15 blur-3xl" />
      <div className="relative mx-auto max-w-6xl px-5 sm:px-8">
        <SectionHeading
          eyebrow="// contact"
          title="Let's work together"
          intro="Have a project idea, an internship opportunity or just want to say hi? Send me a message."
        />

        <div className="grid gap-8 lg:grid-cols-[1fr_1.4fr]">
          <Reveal className="grid content-start gap-4 sm:grid-cols-2 lg:grid-cols-1">
            {contactItems.map(({ Icon, label, value, href }) => {
              const inner = (
                <>
                  <span className="grid h-12 w-12 shrink-0 place-items-center rounded-xl bg-primary/15 text-primary-glow transition-colors group-hover:bg-gradient-primary group-hover:text-primary-foreground">
                    <Icon className="h-5 w-5" />
                  </span>
                  <span className="min-w-0">
                    <span className="block text-xs uppercase tracking-wider text-muted-foreground">{label}</span>
                    <span className="block break-all font-medium text-foreground">{value}</span>
                  </span>
                </>
              );
              const cls =
                "group flex items-center gap-4 rounded-2xl border border-border bg-card p-5 transition-all duration-300";
              return href ? (
                <a key={label} href={href} className={cn(cls, "hover:-translate-y-0.5 hover:border-primary/60")}>
                  {inner}
                </a>
              ) : (
                <div key={label} className={cls}>
                  {inner}
                </div>
              );
            })}
          </Reveal>

          <Reveal delay={120}>
            <div className="rounded-2xl border border-border bg-gradient-card p-5 shadow-card sm:p-8">
              {status === "sent" ? (
                <div
                  role="status"
                  aria-live="polite"
                  className="flex flex-col items-center py-10 text-center animate-in fade-in zoom-in-95 duration-500 sm:py-14"
                >
                  <span className="grid h-20 w-20 place-items-center rounded-full bg-primary/15 shadow-glow">
                    <CheckCircle2 className="h-11 w-11 text-primary-glow" />
                  </span>
                  <h3 className="mt-6 text-2xl font-semibold sm:text-3xl">Thank you{sentName ? `, ${sentName}` : ""}!</h3>
                  <p className="mt-3 max-w-sm text-muted-foreground">
                    Your message has been sent successfully. I'll read it and get back to you by email as soon as
                    I can.
                  </p>
                  <Button variant="glow" className="mt-7 rounded-full" type="button" onClick={() => setStatus("idle")}>
                    Send another message
                  </Button>
                </div>
              ) : (
                <form onSubmit={onSubmit} noValidate className="grid gap-5" aria-label="Contact form">
                  <div className="grid gap-5 sm:grid-cols-2">
                    <Field label="Your name" id="name" required error={errors.name}>
                      <Input
                        ref={nameRef}
                        id="name"
                        name="name"
                        autoComplete="name"
                        value={values.name}
                        onChange={onChange("name")}
                        onBlur={onBlur("name")}
                        maxLength={100}
                        placeholder="Jane Doe"
                        aria-invalid={!!errors.name}
                        aria-describedby={errors.name ? "name-error" : undefined}
                        className={cn("h-11", fieldClass)}
                      />
                    </Field>
                    <Field label="Email" id="email" required error={errors.email}>
                      <Input
                        id="email"
                        name="email"
                        type="email"
                        inputMode="email"
                        autoComplete="email"
                        value={values.email}
                        onChange={onChange("email")}
                        onBlur={onBlur("email")}
                        maxLength={255}
                        placeholder="jane@example.com"
                        aria-invalid={!!errors.email}
                        aria-describedby={errors.email ? "email-error" : undefined}
                        className={cn("h-11", fieldClass)}
                      />
                    </Field>
                  </div>
                  <Field label="Subject" hint="optional" id="subject" error={errors.subject}>
                    <Input
                      id="subject"
                      name="subject"
                      value={values.subject}
                      onChange={onChange("subject")}
                      onBlur={onBlur("subject")}
                      maxLength={150}
                      placeholder="Internship opportunity"
                      aria-invalid={!!errors.subject}
                      aria-describedby={errors.subject ? "subject-error" : undefined}
                      className={cn("h-11", fieldClass)}
                    />
                  </Field>
                  <Field
                    label="Message"
                    id="message"
                    required
                    error={errors.message}
                    counter={`${values.message.length}/${MESSAGE_MAX}`}
                  >
                    <Textarea
                      id="message"
                      name="message"
                      value={values.message}
                      onChange={onChange("message")}
                      onBlur={onBlur("message")}
                      maxLength={MESSAGE_MAX}
                      rows={5}
                      placeholder="Tell me a little about what you have in mind…"
                      aria-invalid={!!errors.message}
                      aria-describedby={errors.message ? "message-error" : undefined}
                      className={cn("resize-none", fieldClass)}
                    />
                  </Field>

                  {/* Hidden from people; catches spam bots. */}
                  <div aria-hidden className="absolute -left-[9999px] h-0 w-0 overflow-hidden">
                    <label htmlFor="website">Website</label>
                    <input
                      id="website"
                      name="website"
                      tabIndex={-1}
                      autoComplete="off"
                      value={honeypot}
                      onChange={(e) => setHoneypot(e.target.value)}
                    />
                  </div>

                  {formError && (
                    <p role="alert" className="flex items-start gap-2 rounded-lg border border-destructive/40 bg-destructive/10 px-4 py-3 text-sm text-destructive">
                      <AlertCircle className="mt-0.5 h-4 w-4 shrink-0" /> {formError}
                    </p>
                  )}

                  <div className="flex flex-col-reverse gap-3 sm:flex-row sm:items-center sm:justify-between">
                    <p className="text-xs text-muted-foreground">
                      <span className="text-primary-glow">*</span> Required fields
                    </p>
                    <Button
                      type="submit"
                      variant="hero"
                      size="xl"
                      disabled={status === "sending"}
                      className="w-full sm:w-auto"
                    >
                      {status === "sending" ? (
                        <>
                          <Loader2 className="animate-spin" /> Sending…
                        </>
                      ) : (
                        <>
                          Send message <Send />
                        </>
                      )}
                    </Button>
                  </div>
                </form>
              )}
            </div>
          </Reveal>
        </div>
      </div>
    </section>
  );
}

function Field({
  label,
  id,
  error,
  required,
  hint,
  counter,
  children,
}: {
  label: string;
  id: string;
  error?: string | undefined;
  required?: boolean;
  hint?: string;
  counter?: string;
  children: ReactNode;
}) {
  return (
    <div className="grid gap-2">
      <div className="flex items-baseline justify-between gap-2">
        <Label htmlFor={id} className="text-sm text-foreground">
          {label}
          {required && <span className="ml-0.5 text-primary-glow">*</span>}
          {hint && <span className="ml-1.5 font-normal text-muted-foreground">({hint})</span>}
        </Label>
        {counter && <span className="font-mono text-xs text-muted-foreground">{counter}</span>}
      </div>
      {children}
      {error && (
        <p id={`${id}-error`} className="flex items-center gap-1.5 text-xs text-destructive animate-in fade-in slide-in-from-top-1">
          <AlertCircle className="h-3.5 w-3.5 shrink-0" /> {error}
        </p>
      )}
    </div>
  );
}
