import { ArrowRight, Github, Linkedin, Mail, MapPin } from "lucide-react";
import { Button } from "@/components/ui/button";
import { profile } from "@/lib/portfolio-data";

export function Hero() {
  return (
    <section id="home" className="relative isolate overflow-hidden bg-hero pt-28 pb-20 sm:pt-32 sm:pb-24 md:pt-40 md:pb-32">
      <div className="bg-grid absolute inset-0 -z-10" aria-hidden />
      <div
        aria-hidden
        className="pointer-events-none absolute -right-24 top-24 -z-10 h-80 w-80 animate-pulse-glow rounded-full bg-primary/25 blur-3xl"
      />

      <div className="mx-auto grid max-w-6xl items-center gap-14 px-5 sm:px-8 lg:grid-cols-[1.15fr_1fr]">
        <div className="min-w-0 animate-in fade-in slide-in-from-bottom-6 duration-700">
          <span className="inline-flex items-center gap-2 rounded-full border border-primary/30 bg-primary/10 px-4 py-1.5 font-mono text-xs text-primary-glow">
            <span className="h-2 w-2 animate-pulse rounded-full bg-primary-glow" />
            Open to internships & projects
          </span>

          <h1 className="mt-6 text-4xl font-extrabold leading-[1.05] sm:text-5xl md:text-6xl lg:text-7xl">
            Hi, I'm <br />
            <span className="text-gradient">{profile.name}</span>
          </h1>

          <p className="mt-5 font-display text-lg font-medium text-primary-glow sm:text-xl">{profile.role}</p>
          <p className="mt-4 max-w-xl text-base leading-relaxed text-muted-foreground sm:text-lg">
            {profile.tagline}
          </p>

          <p className="mt-4 inline-flex items-center gap-2 text-sm text-muted-foreground">
            <MapPin className="h-4 w-4 text-primary-glow" /> {profile.location}
          </p>

          <div className="mt-8 flex flex-wrap gap-3">
            <Button asChild variant="hero" size="xl" className="group flex-1 sm:flex-none">
              <a href="#projects">
                View my work <ArrowRight className="transition-transform group-hover:translate-x-1" />
              </a>
            </Button>
            <Button asChild variant="glow" size="xl" className="flex-1 sm:flex-none">
              <a href="#contact">Get in touch</a>
            </Button>
          </div>

          <div className="mt-8 flex items-center gap-3">
            {[
              { href: profile.github, label: "GitHub", Icon: Github },
              { href: profile.linkedin, label: "LinkedIn", Icon: Linkedin },
              { href: `mailto:${profile.email}`, label: "Email", Icon: Mail },
            ].map(({ href, label, Icon }) => (
              <a
                key={label}
                href={href}
                target={href.startsWith("http") ? "_blank" : undefined}
                rel="noreferrer"
                aria-label={label}
                className="grid h-11 w-11 place-items-center rounded-full border border-border bg-surface text-muted-foreground transition-all duration-300 hover:-translate-y-1 hover:border-primary hover:text-foreground hover:shadow-glow"
              >
                <Icon className="h-5 w-5" />
              </a>
            ))}
          </div>
        </div>

        <CodeCard />
      </div>
    </section>
  );
}

function CodeCard() {
  return (
    <div className="relative min-w-0 animate-in fade-in zoom-in-95 duration-1000">
      <div aria-hidden className="absolute -inset-4 rounded-3xl bg-gradient-primary opacity-20 blur-2xl" />
      <div className="relative animate-float overflow-hidden rounded-2xl border border-border bg-card shadow-card">
        <div className="flex items-center gap-2 border-b border-border bg-surface px-4 py-3">
          <span className="h-3 w-3 rounded-full bg-destructive/80" />
          <span className="h-3 w-3 rounded-full bg-chart-5/70" />
          <span className="h-3 w-3 rounded-full bg-primary-glow/80" />
          <span className="ml-3 font-mono text-xs text-muted-foreground">about_me.py</span>
        </div>
        <pre className="overflow-x-auto p-5 font-mono text-[12px] leading-7 sm:text-sm">
          <code>
            <span className="text-primary-glow">class</span> <span className="text-primary">Student</span>:{"\n"}
            {"    "}name = <span className="text-chart-3">"{profile.name}"</span>{"\n"}
            {"    "}course = <span className="text-chart-3">"{profile.course}"</span>{"\n"}
            {"    "}college = <span className="text-chart-3">"Sahrdaya CAS"</span>{"\n"}
            {"    "}batch = <span className="text-chart-3">"{profile.years.replace(/\s/g, "")}"</span>{"\n"}
            {"    "}skills = [{"\n"}
            {"        "}<span className="text-chart-3">"Python"</span>, <span className="text-chart-3">"HTML"</span>,{"\n"}
            {"        "}<span className="text-chart-3">"CSS"</span>, <span className="text-chart-3">"JavaScript"</span>{"\n"}
            {"    "}]{"\n"}
            {"\n"}
            {"    "}<span className="text-primary-glow">def</span> <span className="text-primary">goal</span>(self):{"\n"}
            {"        "}<span className="text-primary-glow">return</span> <span className="text-chart-3">"Build things that help people"</span>
          </code>
        </pre>
      </div>
    </div>
  );
}
