import { useEffect, useRef, useState } from "react";
import { Braces, FileCode2, Palette, Terminal } from "lucide-react";
import { Reveal, SectionHeading } from "./Reveal";
import { skills, tools } from "@/lib/portfolio-data";

const icons = { Python: Terminal, HTML: FileCode2, CSS: Palette, JavaScript: Braces } as const;

export function Skills() {
  return (
    <section id="skills" className="relative bg-navy-deep py-20 sm:py-24 md:py-32">
      <div className="mx-auto max-w-6xl px-5 sm:px-8">
        <SectionHeading
          eyebrow="// skills"
          title="What I work with"
          intro="The languages and tools I use to learn, experiment and build."
        />

        <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
          {skills.map((s, i) => (
            <Reveal key={s.name} delay={i * 100}>
              <SkillCard {...s} />
            </Reveal>
          ))}
        </div>

        <Reveal className="mt-12 flex flex-wrap justify-center gap-3">
          {tools.map((t) => (
            <span
              key={t}
              className="rounded-full border border-border bg-surface px-4 py-2 text-sm text-muted-foreground transition-colors hover:border-primary hover:text-foreground"
            >
              {t}
            </span>
          ))}
        </Reveal>
      </div>
    </section>
  );
}

function SkillCard({ name, level, note }: { name: string; level: number; note: string }) {
  const Icon = icons[name as keyof typeof icons] ?? Braces;
  const ref = useRef<HTMLDivElement>(null);
  const [filled, setFilled] = useState(false);

  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const obs = new IntersectionObserver(([e]) => {
      if (e?.isIntersecting) {
        setFilled(true);
        obs.disconnect();
      }
    });
    obs.observe(el);
    return () => obs.disconnect();
  }, []);

  return (
    <div
      ref={ref}
      className="group h-full rounded-2xl border border-border bg-gradient-card p-6 shadow-card transition-all duration-300 hover:-translate-y-1.5 hover:border-primary/60 hover:shadow-card-hover"
    >
      <div className="flex items-center justify-between">
        <span className="grid h-12 w-12 place-items-center rounded-xl bg-primary/15 text-primary-glow transition-all duration-300 group-hover:scale-110 group-hover:bg-gradient-primary group-hover:text-primary-foreground">
          <Icon className="h-6 w-6" />
        </span>
        <span className="font-mono text-sm text-muted-foreground">{level}%</span>
      </div>
      <h3 className="mt-5 text-xl font-semibold">{name}</h3>
      <p className="mt-2 text-sm text-muted-foreground">{note}</p>
      <div className="mt-5 h-2 overflow-hidden rounded-full bg-muted">
        <div
          className="h-full rounded-full bg-gradient-primary transition-[width] duration-[1400ms] ease-out"
          style={{ width: filled ? `${level}%` : "0%" }}
        />
      </div>
    </div>
  );
}
