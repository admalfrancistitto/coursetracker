import { BookOpen, Calendar, GraduationCap, MapPin } from "lucide-react";
import { Reveal, SectionHeading } from "./Reveal";
import { profile } from "@/lib/portfolio-data";

export function About() {
  const facts = [
    { Icon: GraduationCap, label: "Course", value: profile.course },
    { Icon: BookOpen, label: "College", value: profile.college },
    { Icon: Calendar, label: "Batch", value: profile.years },
    { Icon: MapPin, label: "Based in", value: profile.location },
  ];

  return (
    <section id="about" className="relative py-20 sm:py-24 md:py-32">
      <div className="mx-auto max-w-6xl px-5 sm:px-8">
        <SectionHeading eyebrow="// about me" title="A curious mind, learning to build" />

        <div className="grid gap-10 lg:grid-cols-[1.1fr_1fr]">
          <Reveal className="space-y-5 text-base leading-relaxed text-muted-foreground sm:text-lg">
            <p>
              I'm <span className="font-semibold text-foreground">{profile.name}</span>, a{" "}
              {profile.course} student at {profile.college} in {profile.location}. I started coding because I
              wanted to understand how the apps I use every day actually work — and I've been hooked ever since.
            </p>
            <p>
              I enjoy writing Python to solve problems and automate small tasks, and building websites with HTML,
              CSS and JavaScript that look good on every screen. I like clean code, clear design and learning
              something new with every project.
            </p>
            <p>
              Right now I'm strengthening my fundamentals in programming, data structures and web development,
              and I'm looking for chances to collaborate, contribute and grow.
            </p>
          </Reveal>

          <div className="grid gap-4 sm:grid-cols-2">
            {facts.map(({ Icon, label, value }, i) => (
              <Reveal key={label} delay={i * 90}>
                <div className="group h-full rounded-2xl border border-border bg-gradient-card p-6 shadow-card transition-all duration-300 hover:-translate-y-1 hover:border-primary/50">
                  <span className="grid h-11 w-11 place-items-center rounded-xl bg-primary/15 text-primary-glow transition-colors group-hover:bg-gradient-primary group-hover:text-primary-foreground">
                    <Icon className="h-5 w-5" />
                  </span>
                  <p className="mt-4 text-xs font-medium uppercase tracking-wider text-muted-foreground">{label}</p>
                  <p className="mt-1 font-display text-base font-semibold text-foreground">{value}</p>
                </div>
              </Reveal>
            ))}
          </div>
        </div>

        <Reveal className="mt-14">
          <div className="relative rounded-2xl border border-border bg-surface p-6 sm:p-8">
            <p className="font-mono text-xs text-primary-glow">// education</p>
            <div className="mt-5 flex gap-5">
              <div className="flex flex-col items-center">
                <span className="h-4 w-4 rounded-full bg-gradient-primary shadow-glow" />
                <span className="mt-2 w-px flex-1 bg-border" />
              </div>
              <div className="pb-2">
                <p className="font-mono text-sm text-muted-foreground">{profile.years}</p>
                <h3 className="mt-1 text-xl font-semibold">{profile.course}</h3>
                <p className="mt-1 text-muted-foreground">
                  {profile.college}, {profile.location}
                </p>
                <p className="mt-3 max-w-2xl text-sm text-muted-foreground">
                  Studying programming, data structures, databases, computer networks and web technologies.
                </p>
              </div>
            </div>
          </div>
        </Reveal>
      </div>
    </section>
  );
}
