import { ArrowUpRight, BarChart3, CloudSun, Github, KanbanSquare } from "lucide-react";
import { Reveal, SectionHeading } from "./Reveal";
import { Button } from "@/components/ui/button";
import { profile, projects } from "@/lib/portfolio-data";
import { prefillContact } from "@/lib/contact-prefill";

const projectIcons = { chart: BarChart3, cloud: CloudSun, board: KanbanSquare } as const;

export function Projects() {
  return (
    <section id="projects" className="relative py-20 sm:py-24 md:py-32">
      <div className="mx-auto max-w-6xl px-5 sm:px-8">
        <SectionHeading
          eyebrow="// projects"
          title="Things I've built"
          intro="A few projects where I put what I've learned into practice."
        />

        <div className="grid gap-7 md:grid-cols-2 lg:grid-cols-3">
          {projects.map((p, i) => (
            <Reveal key={p.title} delay={i * 120}>
              <article className="group flex h-full flex-col overflow-hidden rounded-2xl border border-border bg-card shadow-card transition-all duration-500 hover:-translate-y-2 hover:border-primary/60 hover:shadow-card-hover">
                <ProjectBanner icon={p.icon} index={i} />
                <div className="flex flex-1 flex-col p-6">
                  <h3 className="text-xl font-semibold transition-colors group-hover:text-primary-glow">{p.title}</h3>
                  <p className="mt-3 flex-1 text-sm leading-relaxed text-muted-foreground">{p.description}</p>
                  <div className="mt-5 flex flex-wrap gap-2">
                    {p.tags.map((t) => (
                      <span key={t} className="rounded-md bg-primary/10 px-2.5 py-1 font-mono text-xs text-primary-glow">
                        {t}
                      </span>
                    ))}
                  </div>
                  <div className="mt-6 flex gap-2 border-t border-border pt-5">
                    <Button asChild variant="glow" size="sm" className="rounded-full">
                      <a href={profile.github} target="_blank" rel="noreferrer" aria-label={`${p.title} on GitHub`}>
                        <Github /> GitHub
                      </a>
                    </Button>
                    <Button
                      type="button"
                      variant="ghost"
                      size="sm"
                      className="group/ask rounded-full"
                      onClick={() => prefillContact(`About your project: ${p.title}`)}
                    >
                      Ask about it{" "}
                      <ArrowUpRight className="transition-transform group-hover/ask:-translate-y-0.5 group-hover/ask:translate-x-0.5" />
                    </Button>
                  </div>
                </div>
              </article>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}

function ProjectBanner({ icon, index }: { icon: keyof typeof projectIcons; index: number }) {
  const Icon = projectIcons[icon];
  return (
    <div className="relative aspect-[16/9] overflow-hidden border-b border-border bg-surface">
      <div className="bg-grid absolute inset-0" aria-hidden />
      <div
        aria-hidden
        className="absolute left-1/2 top-1/2 h-40 w-40 -translate-x-1/2 -translate-y-1/2 rounded-full bg-primary/25 blur-3xl transition-opacity duration-500 group-hover:opacity-100 opacity-60"
      />
      <div className="relative flex h-full items-center justify-center">
        <span className="grid h-20 w-20 place-items-center rounded-2xl bg-gradient-primary text-primary-foreground shadow-glow transition-transform duration-500 group-hover:-rotate-6 group-hover:scale-110">
          <Icon className="h-9 w-9" />
        </span>
      </div>
      <span className="absolute left-4 top-4 rounded-full glass px-3 py-1 font-mono text-xs text-primary-glow">
        0{index + 1}
      </span>
      <span className="absolute bottom-4 right-4 font-mono text-xs text-muted-foreground">{"</>"}</span>
    </div>
  );
}
