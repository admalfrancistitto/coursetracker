# Admal Francis Titto — Portfolio source

This archive contains the website source, styles, contact form, tests, and database migration. It does not include installed dependencies, build output, repository history, or private environment settings.

## Run locally

1. Install a current Node.js release and Bun.
2. Open a terminal in this folder.
3. Copy `.env.example` to `.env` and fill in your own backend connection settings. These are required for the contact form and the backend client.
4. Run `bun install`.
5. Run `bun run dev` and open the local address printed in the terminal.

Run tests with `bun run test`.

## Content

Edit `src/lib/portfolio-data.ts` to change personal details, skills, and projects.

## Contact form

The contact form saves messages to the existing Lovable Cloud backend when configured with that backend's public connection settings. The archive does not contain saved messages or a running backend. To use a separate backend, create the table and insert-only access rules using `drizzle/migrations/0000_migration.sql`. Never put private server keys in VITE_ variables.

This ZIP is source code, not a ready-to-upload static HTML website.
